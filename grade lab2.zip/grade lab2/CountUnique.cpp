#include <stdio.h>


#define  MAXSIZE  10
#define  MINSIZE   8

int  SIZE, SIZEE;
int  BOARD[MAXSIZE], * BOARDE, * BOARD1, * BOARD2;
int  MASK, TOPBIT, SIDEMASK, LASTMASK, ENDBIT;
int  BOUND1, BOUND2;

int  COUNT8, COUNT4, COUNT2;
int  TOTAL, UNIQUE;


void Display(void)
{
    int  y, bit;

    printf("N= %d\n", SIZE);
    for (y = 0; y < SIZE; y++) {
        for (bit = TOPBIT; bit; bit >>= 1)
            printf("%s ", (BOARD[y] & bit) ? "Q" : "-");
        printf("\n");
    }
    printf("\n");
}

void Check(void)
{
    int* own, * you, bit, ptn;

    /* 90-degree rotation */
    if (*BOARD2 == 1) {
        for (ptn = 2, own = BOARD + 1; own <= BOARDE; own++, ptn <<= 1) {
            bit = 1;
            for (you = BOARDE; *you != ptn && *own >= bit; you--)
                bit <<= 1;
            if (*own > bit) return;
            if (*own < bit) break;
        }
        if (own > BOARDE) {
            COUNT2++;
            
            return;
        }
    }

    /* 180-degree rotation */
    if (*BOARDE == ENDBIT) {
        for (you = BOARDE - 1, own = BOARD + 1; own <= BOARDE; own++, you--) {
            bit = 1;
            for (ptn = TOPBIT; ptn != *you && *own >= bit; ptn >>= 1)
                bit <<= 1;
            if (*own > bit) return;
            if (*own < bit) break;
        }
        if (own > BOARDE) {
            COUNT4++;
          
            return;
        }
    }

    /* 270-degree rotation */
    if (*BOARD1 == TOPBIT) {
        for (ptn = TOPBIT >> 1, own = BOARD + 1; own <= BOARDE; own++, ptn >>= 1) {
            bit = 1;
            for (you = BOARD; *you != ptn && *own >= bit; you++)
                bit <<= 1;
            if (*own > bit) return;
            if (*own < bit) break;
        }
    }
    COUNT8++;
    
}

void Backtrack2(int y, int left, int down, int right)
{
    int  bitmap, bit;

    bitmap = MASK & ~(left | down | right);
    if (y == SIZEE) {
        if (bitmap) {
            if (!(bitmap & LASTMASK)) {
                BOARD[y] = bitmap;
                Check();
            }
        }
    }
    else {
        if (y < BOUND1) {
            bitmap |= SIDEMASK;
            bitmap ^= SIDEMASK;
        }
        else if (y == BOUND2) {
            if (!(down & SIDEMASK)) return;
            if ((down & SIDEMASK) != SIDEMASK) bitmap &= SIDEMASK;
        }
        while (bitmap) {
            bitmap ^= BOARD[y] = bit = -bitmap & bitmap;
            Backtrack2(y + 1, (left | bit) << 1, down | bit, (right | bit) >> 1);
        }
    }
}

void Backtrack1(int y, int left, int down, int right)
{
    int  bitmap, bit;

    bitmap = MASK & ~(left | down | right);
    if (y == SIZEE) {
        if (bitmap) {
            BOARD[y] = bitmap;
            COUNT8++;
           
        }
    }
    else {
        if (y < BOUND1) {
            bitmap |= 2;
            bitmap ^= 2;
        }
        while (bitmap) {
            bitmap ^= BOARD[y] = bit = -bitmap & bitmap;
            Backtrack1(y + 1, (left | bit) << 1, down | bit, (right | bit) >> 1);
        }
    }
}

void NQueens(void)
{
    int  bit;

   
    COUNT8 = COUNT4 = COUNT2 = 0;
    SIZEE = SIZE - 1;
    BOARDE = &BOARD[SIZEE];
    TOPBIT = 1 << SIZEE;
    MASK = (1 << SIZE) - 1;

   
    BOARD[0] = 1;
    for (BOUND1 = 2; BOUND1 < SIZEE; BOUND1++) {
        BOARD[1] = bit = 1 << BOUND1;
        Backtrack1(2, (2 | bit) << 1, 1 | bit, bit >> 1);
    }

    SIDEMASK = LASTMASK = TOPBIT | 1;
    ENDBIT = TOPBIT >> 1;
    for (BOUND1 = 1, BOUND2 = SIZE - 2; BOUND1 < BOUND2; BOUND1++, BOUND2--) {
        BOARD1 = &BOARD[BOUND1];
        BOARD2 = &BOARD[BOUND2];
        BOARD[0] = bit = 1 << BOUND1;
        Backtrack2(1, bit << 1, bit, bit >> 1);
        LASTMASK |= LASTMASK >> 1 | LASTMASK << 1;
        ENDBIT >>= 1;
    }

    
    UNIQUE = COUNT8 + COUNT4 + COUNT2;
    TOTAL = COUNT8 * 8 + COUNT4 * 4 + COUNT2 * 2;
}


int main(void)
{
   
    char form[20];

    printf("<------  N-Queens Solutions  -----> \n");
    printf(" N:           Total          Unique \n");
    for (SIZE = 8; SIZE <= 10; SIZE++) {
        NQueens();
        printf("%2d:%16d%16d\n", SIZE, TOTAL, UNIQUE);
    }

    return 0;
}
