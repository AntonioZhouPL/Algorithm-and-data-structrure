#include <iostream>
#include <algorithm>

using namespace std;

bool isConsistent(int q[], int n) {
        for (int i = 0; i < n; i++) {
            if (q[i] == q[n])             return false;   
            if ((q[i] - q[n]) == (n - i)) return false;   
            if ((q[n] - q[i]) == (n - i)) return false;   
        }
        return true;
}

void printQueens(int q[], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (q[i] == j) cout << "1 ";
            else           cout << "0 ";
        }
        cout << endl;
    }  
    cout << endl;
}

void placeQueensHelper(int q[], int k, int size) {
        if (k == size) {
            printQueens(q, size);
        } else {
            for (int i = 0; i < size; i++) {
                q[k] = i;
                if (isConsistent(q, k)) placeQueensHelper(q, k+1, size);
            }
        }
}  

void placeQueens(int n) {
        int a[n];
        placeQueensHelper(a, 0, n);
}



int main(int argc, char *argv[]) {
    int N;
    cout << "Enter the number of Queens: ";
    cin >> N;
    placeQueens(N); 

}
