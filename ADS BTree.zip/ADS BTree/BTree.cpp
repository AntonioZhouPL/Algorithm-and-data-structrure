#include <iostream>
#include <stdlib.h>

using namespace std;

struct node {
  int key;
  struct node *left, *right;
};

// Create a node
struct node *new_Node(int item) {
  struct node *temp = (struct node *)malloc(sizeof(struct node));
  temp->key = item;
  temp->left = temp->right = NULL;
  return temp;
}

// Inorder Traversal
void in_order(struct node *root) {
  if (root != NULL) {
    // Traverse left
    in_order(root->left);

    // Traverse root
    cout << root->key << " -> ";

    // Traverse right
    in_order(root->right);
  }
}

// Insert a node
struct node *insert_Data(struct node *node, int key) {
  // Return a new node if the tree is empty
  if (node == NULL) return new_Node(key);

  // Traverse to the right place and insert_Data the node
  if (key < node->key)
    node->left = insert_Data(node->left, key);
  else
    node->right = insert_Data(node->right, key);

  return node;
}

// Find the in_order successor
struct node *min_Value_Node(struct node *node) {
  struct node *current = node;

  // Find the leftmost leaf
  while (current && current->left != NULL)
    current = current->left;

  return current;
}

// Deleting a node
struct node *delete_Node(struct node *root, int key) {
  // Return if the tree is empty
  if (root == NULL) return root;

  // Find the node to be deleted
  if (key < root->key)
    root->left = delete_Node(root->left, key);
  else if (key > root->key)
    root->right = delete_Node(root->right, key);
  else {
    // If the node is with only one child or no child
    if (root->left == NULL) {
      struct node *temp = root->right;
      free(root);
      return temp;
    } else if (root->right == NULL) {
      struct node *temp = root->left;
      free(root);
      return temp;
    }

    // If the node has two children
    struct node *temp = min_Value_Node(root->right);

    // Place the in_order successor in position of the node to be deleted
    root->key = temp->key;

    // Delete the in_order successor
    root->right = delete_Node(root->right, temp->key);
  }
  return root;
}

// Driver code
int main() {
  struct node *root = NULL;
  root = insert_Data(root, 8);
  root = insert_Data(root, 3);
  root = insert_Data(root, 1);
  root = insert_Data(root, 6);
  root = insert_Data(root, 7);
  root = insert_Data(root, 10);
  root = insert_Data(root, 14);
  root = insert_Data(root, 4);

  cout << "Inorder traversal: ";
  in_order(root);

  cout << "\nAfter deleting 10\n";
  root = delete_Node(root, 10);
  cout << "Inorder traversal: ";
  in_order(root);
}