#include <iostream>

using namespace std;

class Node
{
public:
    Node *left;
    Node *right;
    char data;

    Node(char data)
    {
        this->data = data;
        left = NULL;
        right = NULL;
    }
};

class AVL
{
private:
    Node *root;

public:
    AVL()
    {
        root = NULL;
    }

    void balanced()
    {
        cout << "After balanced: ";
        balancehelper(root);
        cout << "\n";
    }

    void balancehelper(Node *root)
    {
        if (root == NULL)
            return;
        balancehelper(root->left);
        cout << root->data << " , ";
        balancehelper(root->right);
    }

    void insert(int data) // Insert function use for Insertion of data
    {
        root = insertHelper(root, data);
    }

    // Question 2.

    Node *insertHelper(Node *root, int data) // InsertHelper Function takes root and data as parameter
    {
        if (root == NULL) // we first place a node into the appropriate place in binary search tree order.
        {
            return new Node(data);
        }

        if (root->data < data) // Here if data is bigger than root's data, it will go to right part of tree because of the definition of the Avl tree
        {
            root->right = insertHelper(root->right, data);
        }

        else // Here if data is less than root's data, it will go to left part of tree because of the definition of the Avl tree
        {
            root->left = insertHelper(root->left, data);
        }

        int lh = height(root->left);  // void height of Left Sub Tree
        int rh = height(root->right); // void height of right sub Tree

        // If height difference is greater than Two than we will have Rotations
        // And then we start to rotation

        // pseudocode for RIGHT-ROTATE

        if (lh - rh < -1) // If  height of Left Sub Tree is less than height of right sub Tree
        {
            if (root->right->data < data)

            {
                // Right Right Rotation
                return rr(root, root->right);
            }
            else
            {
                // Right Left Rotation
                return rl(root, root->right);
            }
        }
        else if (lh - rh > 1) // If  height of Left Sub Tree is more than height of right sub Tree
        {
            if (root->left->data < data)
            {
                // Left Right Rotation
                return lr(root, root->left);
            }
            else
            {
                // Left Left Rotation
                return ll(root, root->left);
            }
        }
        return root;
    }
    int height(Node *root) // return height of tree at any level
    {
        if (root == NULL)
            return 0;
        return max(height(root->left), height(root->right)) + 1;
    }

    // Question 3.

    // Right Right rotation which returns the Node After Balancing the tree(pseudocode for RIGHT-ROTATE)
    Node *rr(Node *x, Node *y)
    {
        Node *LST = y->left;
        y->left = x;
        x->right = LST;
        return y;
    }
    // Left Left rotation which returns the Node After Balancing the tree(pseudocode for LEFT-ROTATE)
    Node *ll(Node *x, Node *y)
    {
        Node *RST = y->right;
        y->right = x;
        x->left = RST;
        return y;
    }
    // Right left rotation which returns the Node After Balancing the tree
    Node *rl(Node *x, Node *y)
    {
        Node *z = y->left;
        Node *RST = z->right;

        y->left = RST;
        x->right = z;
        z->right = y;
        // converting rl to rr
        return rr(x, z);
    }
    // Left Right rotation which returns the Node After Balancing the tree
    Node *lr(Node *x, Node *y)
    {
        Node *z = y->right;
        Node *LST = z->left;

        x->left = z;
        z->left = y;
        y->right = LST;
        // Here, we convert lr to ll
        return ll(x, z);
    }
};

int main()
{

    AVL avl;
    avl.insert('H');
    avl.insert('I');
    avl.insert('J');
    avl.insert('B');
    avl.insert('A');
    avl.insert('E');
    avl.insert('C');
    avl.insert('F');
    avl.insert('D');
    avl.insert('G');
    avl.insert('K');
    avl.insert('L');
    avl.balanced();
    return 0;
}